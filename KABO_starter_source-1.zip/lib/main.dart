import 'package:flutter/material.dart';

void main() => runApp(const KaboApp());

const kPurple = Color(0xFF8B5CF6);
const kGold = Color(0xFFFFD166);
const kBg = Color(0xFF100D19);
const kPanel = Color(0xFF1B1628);

class KaboApp extends StatelessWidget {
  const KaboApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KABO',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kPurple,
          brightness: Brightness.dark,
          surface: kPanel,
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class VoiceRoom {
  final String title, host, category, emoji;
  final int people;
  const VoiceRoom(this.title, this.host, this.category, this.people, this.emoji);
}

const rooms = [
  VoiceRoom('سهرة كابو 🎙️', 'KABO Star', 'شعبية', 128, '🎤'),
  VoiceRoom('أصحاب وبس', 'Mido', 'أصدقاء', 46, '🤝'),
  VoiceRoom('تحدي المعلومات', 'Lolo', 'ألعاب', 32, '🎮'),
  VoiceRoom('قعدة رايقة', 'Nour', 'تعارف', 21, '🌙'),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedTab = 0;
  String selectedCategory = 'الكل';
  final categories = const ['الكل', 'شعبية', 'ألعاب', 'تعارف', 'أصدقاء'];

  @override
  Widget build(BuildContext context) {
    final visibleRooms = rooms.where((r) =>
        selectedCategory == 'الكل' || r.category == selectedCategory).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(child: _header()),
              SliverToBoxAdapter(child: _wallet()),
              SliverToBoxAdapter(child: _hero()),
              SliverToBoxAdapter(child: _sectionTitle('اكتشف الغرف', 'عرض الكل')),
              SliverToBoxAdapter(child: _categories()),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                sliver: SliverList.separated(
                  itemCount: visibleRooms.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) => _roomCard(visibleRooms[i]),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          backgroundColor: const Color(0xFF171222),
          indicatorColor: kPurple.withOpacity(.25),
          selectedIndex: selectedTab,
          onDestinationSelected: (v) => setState(() => selectedTab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.explore_rounded), label: 'اكتشف'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), label: 'إنشاء'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'الرسائل'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
      ),
    );
  }

  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
    child: Row(children: [
      Container(
        width: 48, height: 48,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [kPurple, Color(0xFF4C1D95)]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: kPurple.withOpacity(.25), blurRadius: 16)],
        ),
        child: const Center(child: Text('🐥', style: TextStyle(fontSize: 27))),
      ),
      const SizedBox(width: 12),
      const Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('KABO', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
          Text('صوتك يجمعنا', style: TextStyle(color: Colors.white60, fontSize: 12)),
        ],
      )),
      _roundIcon(Icons.search_rounded),
      const SizedBox(width: 8),
      _roundIcon(Icons.notifications_none_rounded),
    ]),
  );

  Widget _roundIcon(IconData icon) => Container(
    width: 42, height: 42,
    decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(14)),
    child: IconButton(onPressed: () {}, icon: Icon(icon, size: 21)),
  );

  Widget _wallet() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: kPanel, borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(.06)),
      ),
      child: Row(children: [
        const Icon(Icons.account_circle_rounded, size: 32, color: kPurple),
        const SizedBox(width: 10),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ضيف كابو', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('المستوى 1  •  ID: —', style: TextStyle(color: Colors.white54, fontSize: 11)),
        ])),
        const Icon(Icons.monetization_on_rounded, color: kGold),
        const SizedBox(width: 5),
        const Text('0', style: TextStyle(color: kGold, fontWeight: FontWeight.bold)),
        const SizedBox(width: 6),
        const Icon(Icons.chevron_left, color: Colors.white54),
      ]),
    ),
  );

  Widget _hero() => Padding(
    padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
    child: Container(
      height: 158,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topRight, end: Alignment.bottomLeft,
          colors: [Color(0xFF5726A8), Color(0xFF24163E), Color(0xFF171222)],
        ),
        border: Border.all(color: kPurple.withOpacity(.45)),
      ),
      child: Row(children: [
        const Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('أهلاً بيك في كابو', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            SizedBox(height: 7),
            Text('ادخل قعدة جديدة، واتعرف على ناس شبهك', style: TextStyle(color: Colors.white70, fontSize: 12)),
            SizedBox(height: 14),
            Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.graphic_eq_rounded, color: kGold, size: 18),
              SizedBox(width: 6),
              Text('صوت • صحبة • لحظات', style: TextStyle(color: kGold, fontSize: 11, fontWeight: FontWeight.bold)),
            ]),
          ],
        )),
        const Text('🐥', style: TextStyle(fontSize: 66)),
      ]),
    ),
  );

  Widget _sectionTitle(String title, String action) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
    child: Row(children: [
      Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
      Text(action, style: const TextStyle(color: kPurple, fontSize: 12, fontWeight: FontWeight.bold)),
    ]),
  );

  Widget _categories() => SizedBox(
    height: 45,
    child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      scrollDirection: Axis.horizontal,
      itemCount: categories.length,
      separatorBuilder: (_, __) => const SizedBox(width: 8),
      itemBuilder: (_, i) {
        final category = categories[i];
        final active = category == selectedCategory;
        return ChoiceChip(
          label: Text(category),
          selected: active,
          onSelected: (_) => setState(() => selectedCategory = category),
          selectedColor: kPurple,
          backgroundColor: kPanel,
          side: BorderSide(color: active ? kPurple : Colors.white12),
          labelStyle: TextStyle(color: active ? Colors.white : Colors.white70, fontSize: 12),
        );
      },
    ),
  );

  Widget _roomCard(VoiceRoom room) => InkWell(
    borderRadius: BorderRadius.circular(20),
    onTap: () => _showRoomPreview(room),
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kPanel,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(.055)),
      ),
      child: Row(children: [
        Container(
          width: 58, height: 58,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(17),
            gradient: const LinearGradient(colors: [Color(0xFF6D28D9), Color(0xFF2E1065)]),
          ),
          child: Center(child: Text(room.emoji, style: const TextStyle(fontSize: 28))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(room.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 5),
          Text('بواسطة ${room.host}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
          const SizedBox(height: 8),
          Row(children: [
            Container(width: 6, height: 6, decoration: const BoxDecoration(color: Color(0xFF4ADE80), shape: BoxShape.circle)),
            const SizedBox(width: 5),
            Text(room.category, style: const TextStyle(color: Colors.white60, fontSize: 10)),
          ]),
        ])),
        Column(children: [
          const Icon(Icons.people_alt_outlined, color: kGold, size: 18),
          const SizedBox(height: 4),
          Text('${room.people}', style: const TextStyle(color: Colors.white70, fontSize: 11)),
        ]),
      ]),
    ),
  );

  void _showRoomPreview(VoiceRoom room) {
    showModalBottomSheet(
      context: context,
      backgroundColor: kPanel,
      showDragHandle: true,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 30),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(room.emoji, style: const TextStyle(fontSize: 46)),
            const SizedBox(height: 8),
            Text(room.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('الغرفة دي نموذج واجهة تجريبي — لم يتم ربط الصوت بعد.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(.65))),
            const SizedBox(height: 18),
            SizedBox(width: double.infinity, child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: kPurple),
              onPressed: () => Navigator.pop(context),
              child: const Text('تمام'),
            )),
          ]),
        ),
      ),
    );
  }
}
